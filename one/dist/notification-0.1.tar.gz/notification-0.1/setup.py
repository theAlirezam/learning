from setuptools import setup

setup(
    name='notification',
    author='alireza',
    version='0.1',
    packages=['notification-pack']

)
